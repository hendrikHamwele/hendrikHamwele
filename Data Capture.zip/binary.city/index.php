<?php 
	include_once("library/controller/controller.php");
	$controller = new Controller();
	$controller->control();

?>
