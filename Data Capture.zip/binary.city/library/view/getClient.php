<?php
$pageTitle ='View Clients';
require_once("inc/header_footer/header.php");
    if($content!='404'){
?>
<div class="table-wrapper">
    <table border="1" cellpadding="0" cellspacing="0">	
        <tbody>
            <tr>
                <th scope="col">Name</th>
                <th scope="col">Client Code</th>
                <th scope="col">Total Number of Contacts</th>
                <th scope="col">Action</th>
            </tr> 
            <?php echo $content;?>          
        </tbody>
    </table>
</div>
<?php
    }else{
        ?>
        <span> No Client(s) Found.</span>
<?php
    }
require_once("inc/header_footer/footer.php");