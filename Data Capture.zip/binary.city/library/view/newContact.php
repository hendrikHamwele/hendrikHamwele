<?php
$pageTitle ='Add Contact';
require_once("inc/header_footer/header.php");
?>

<div class="Form-wrapper">
    <div class="main-error-wrapper"></div>
    <div class="input-wrapper">
        <input type="text" name="first_name" placeholder="First Name" id="first_name"/>
    </div>
    <div class="input-wrapper">
        <input type="text" name="surname" placeholder="Surname" id="surname"/>
    </div>

    <div class="input-wrapper">
        <input type="email" name="email" placeholder="Email" id="email"/>
    </div>

    <button id="addContactButton">Add Contact</button>
    <input type="hidden" value="<?php echo $_GET['client'];?>" id="clientCode" name="clientCode" disabled hidden/>
</div>
<?php
require_once("inc/header_footer/footer.php");

