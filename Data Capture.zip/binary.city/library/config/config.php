<?php
require_once("dbAdapater.php");
/*************************************************************************************/
/*************************| UNIVERSAL SITE CONFIGURATIONS |**************************/
/***********************************************************************************/
class systemConfiguration{
    /**/
    var $configSettings;
    /* MySQL Database settings */
    function getDBConfigurations(){
        $configSettings['DB_HOST'] = 'localhost';
        $configSettings['DB_USER'] = 'root';
        $configSettings['DB_PASSWORD'] = '';
        $configSettings['DB_NAME'] = 'binary_city';

        return $configSettings;
    }     
}

$configSett = new systemConfiguration();

