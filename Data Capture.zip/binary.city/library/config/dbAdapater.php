<?php 
require_once("config.php");
/**************************************************************************/
/*************************| DATABASE CONNECTOR |**************************/
/************************************************************************/
class dbAdapater extends systemConfiguration{
    // Load settings from parent class
    function __construct(){
        $configSettings = systemConfiguration::getDBConfigurations();
        
        $dbhost 	= $configSettings['DB_HOST'];
        $databaseName 	= $configSettings['DB_NAME'];
        $username 	= $configSettings['DB_USER'];
        $password 	= $configSettings['DB_PASSWORD'];

        $DSN= "mysql:host=$dbhost;dbname=$databaseName";
        
        try
        {
            $this->dbh= new PDO($DSN,$username,$password);
            $this->dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        catch(PDOException $e)
        {
            die("Opps an error occured, unfortunatley a database problem has been detected.");
        }
    }

    function __destruct(){
        $this->dbh=null;
    }
    
	function queryExecute($query, $conditions_array){
		$result = $this->dbh->prepare($query);
		$result->execute($conditions_array);
		return $result;
	}

    function fetchArray($result) {
        $array = $result->fetch();
        return $array;
    }

    function rowResults($result) {
        $count = $result->rowCount();
        return $count;
    }
}