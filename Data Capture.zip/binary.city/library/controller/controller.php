<?php
require_once("library/model/model.php");
class Controller{
    public function control(){

        if(!isset($_GET['action'])){
            include 'library/view/index.php';
        }   
        else{
            $action = $_GET['action'];
            switch ($action) {
                case ($action === "newClient"):
                    include 'library/view/newClient.php';
                break;
                /**/
                case ($action === "newContact"):
                    include 'library/view/newContact.php';
                break;
                /**/
                case ($action === "getClient"):
                    $model = new Model();                    
                    $content = $model->getClient();
                    include 'library/view/getClient.php';
                break;
                /**/
                case ($action === "getContact"):
                    include 'library/view/getContact.php';
                break;
                /**/
                default:
                require "views/start.php";
                break;
            }
        }
    }
}