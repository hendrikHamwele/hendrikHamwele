<?php
require_once("library/config/config.php");

class Model extends dbAdapater {

    function __construct(){}
    function __destruct(){unset($adapter);}
    
    public function newClient($jsonEncodedData){
        
    }
    public function newContact(){

    }
    public function getClient(){
        
        $adapter = new dbAdapater();
		$result = $adapter->queryExecute("SELECT * FROM clients", array());        
        $count = $adapter->rowResults($result);
        $txt='';
        if($count ==0){
            $txt='404';
        }
        else{
            while($row= $adapter->fetchArray($result)){
                $txt .='<tr>';
                $txt .='<td data-label="Name">'.$row['client_name'].'</td>';
                $txt .='<td data-label="Client Code">'.$row['client_code'].'</td>';
                $txt .='<td data-label="Total Number of Contacts">'.$row['num_contacts'].'</td>';
                $txt .='<td data-label="Action"><a href="?action=newContact&client='.$row['client_code'].'">Add Contact</a></td>';
                $txt .='</tr>';
            }
        }
        return $txt;
    }
    public function getContact(){

    }
}

$model = new Model();
