CREATE TABLE CLIENTS(
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_name VARCHAR(100) NOT NULL,
    client_code VARCHAR(15) NOT NULL,
    num_contacts int null

);

CREATE TABLE CONTACTS(
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(25) NOT NULL,
    surname VARCHAR(25) NOT NULL,
    email VARCHAR(125) NOT NULL,
    client_code VARCHAR(15) NOT NULL
);