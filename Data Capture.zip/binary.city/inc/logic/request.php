<?php
include("../../library/model/model.php");
if(isset($_POST['addContact']) && $_POST['addContact']==200){
    $data = $_POST['formData'];

    $firstname = htmlspecialchars(strip_tags($data[0]));
    $surname = htmlspecialchars(strip_tags($data[1]));
    $email = htmlspecialchars(strip_tags($data[2]));
    $clientCode = htmlspecialchars(strip_tags($data[3]));
    
}