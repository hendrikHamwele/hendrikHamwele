<!DOCTYPE html>
<html lang="en" >
	<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta id="apple-mobile-web-app-capable" content='yes' name='apple-mobile-web-app-capable'/>
        <meta id="Content-Type" http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta id="content-language" http-equiv="content-language" content="en"/>
        <meta id="language" name="language" content="English"/>
        <meta id="coverage" name="coverage" content="Worldwide"/>

        <meta id="robots" name="robots" content="index, follow"/>
        <meta id="X-UA-Compatible" http-equiv="X-UA-Compatible" content="IE=Edge" >
        <meta id="viewport" name="viewport" content="width=device-width, maximum-scale=1.0" />
        <title><?php echo $pageTitle;?></title>

        <link rel="stylesheet" href="inc/css/styles.css">
    </head>
<body> 
    