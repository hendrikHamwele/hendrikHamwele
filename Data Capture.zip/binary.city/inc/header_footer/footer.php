<script src="inc/js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="inc/js/index.js"></script>
</body>
</html>