


$( document ).ready(function() {
    
    $("#addContactButton").click(function() {

        var clientCode;
        clientCode = $('#clientCode').val().replace(/<\/?[^>]+(>|$)/g, "");
    
        if(clientCode == null || clientCode ==''){
            $("#addContactButton").remove();
            return false;
        }else{
            var firstName, surname, email, validationErrorCount;
            firstName = $('#first_name').val().replace(/<\/?[^>]+(>|$)/g, "");
            surname = $('#surname').val().replace(/<\/?[^>]+(>|$)/g, "");
            email = $('#email').val().replace(/<\/?[^>]+(>|$)/g, "");
            validationErrorCount = validation(firstName,surname,email);
            if(validationErrorCount !=0){
                $(".main-error-wrapper").html("<p>Submission failed, you have "+validationErrorCount+" Errors! ");
            }else{
                $('.main-error-wrapper').html('');
                var preparedData = [firstName,surname,email,clientCode];
                $.ajax({
                    url:"inc/logic/request.php",
                    type:'post',
                    data: {addContact:200,formData:preparedData},
                    dataType:'html',
                    success: function(response)
                    {  
                        console.log(response);
                    }
                });
            }
        }/*END OF ELSE */
    });
});

function isEmail(email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
}
function validation(firstName,surname,email){
    var errorCount = 0;

    if(firstName == null || firstName ==''){
        $parentElement =  $("#first_name").parent();
       $($parentElement).append('<p>This field is required, please complete field.</p>');
       errorCount ++;
    }else if(firstName.length < 2){
        $parentElement =  $("#first_name").parent();
        $($parentElement).append('<p>Provided first name should be more than 1 characters.</p>');
    }

    if(surname == null || surname ==''){
        $parentElement =  $("#surname").parent();
       $($parentElement).append('<p>This field is required, please complete field.</p>');
       errorCount ++;
    }else if(surname.length < 2){
        $parentElement =  $("#surname").parent();
        $($parentElement).append('<p>Provided surname should be more than 1 characters.</p>');
    }

    if(email == null || email ==''){
        $parentElement =  $("#email").parent();
       $($parentElement).append('<p>This field is required, please complete field.</p>');
       errorCount ++;
    }else if(!isEmail(email)){
        $parentElement =  $("#email").parent();
       $($parentElement).append('<p>Please provide a valid email address.</p>');
    }
    $(document).ready(function(){
        $("#first_name").on("input", function(){
            if(firstName.length < 2 && firstName !=null){
                $("#first_name").next().remove();
            }
        });
        $("#surname").on("input", function(){
            if(surname.length < 2 && firstName !=null){
                $("#surname").next().remove();
            }
        });
        $("#email").on("input", function(){
            if(email.length < 2){
                $("#email").next().remove();
            }
        });
    });
    return errorCount;
}

function openTab(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}